/**
 * Base class for all dumps
 *
 * @author sanjay nair (sanjaysn@usc.edu)
 * @version 
 *   03/12/2006 - Created
 */

#ifndef __BASEDUMP_H__
#define __BASEDUMP_H__

#include <stdio.h>
#include <string>
#include <assert.h>

class BaseDump {

public:
    
    /**
     * C'tor.
     *
     * @param filePath          File path
     * @param soPath            Shared libary Path
     */
    BaseDump( const std::string filePath, const std::string soPath );

    /**
     * Virtual D'tor.
     */
    virtual ~BaseDump();

    /**
     * Dumps the output (based on input file or stdin)
     */
    virtual int dump() = 0;

protected:
    
    /**
     * Opens the input file. If the file path is valid and open is successful,
     * this methid creates a valid file pointer and keeps it. In this case, the
     * return code will be 0. Otherwise, return code will be non-zero.
     * 
     * @param mustExist             Parameter to check if the file exists.
     *                              If this parameter is false and the filepath
     *                              is empty, stdin will be the default file pointer.
     */
    virtual int openInputFile( bool mustExist );

    /**
     * Opens the input file. If the file path is valid and open is successful,
     * this methid creates a valid file pointer and keeps it. In this case, the
     * return code will be 0. Otherwise, return code will be non-zero.
     * 
     */
    virtual int closeInputFile();

    /**
     * Checks the read status of the file. If the read status is not
     * correct, this method will update the error message and returns 
     * error code.
     */
    virtual int checkFileReadStatus() const;

    /**
     * Returns the openssl error string 
     *
     * @param errorCode         Error code. 
     *
     * @return                  Error string if available,else "No information available"
     */
    std::string getOpenSslErrStr( int errorCode ) const;

    std::string _filePath;
    std::string _soPath;
    FILE * _fp;
};

#endif //__BASEDUMP_H__

